
Copy the correct config file to your install direcetory (where the wallet.dat get put by the client).
This is normally %appdata%/NiftyCoin

MAIN (NORMAL)
===============
If you are using the main net and not the test net - copy the niftycoin.conf.mainnet file into the folder mentioned above, 
and rename to niftycoin.conf.


TEST
===============
If you instead are using the test net - copy the niftycoin.conf.testnet file into the folder mentioned above, 
and rename to niftycoin.conf.


And then start your niftycoin-qt.exe client.